# ایجاد پوشه اصلی پروژه
mkdir -p family-counseling-ui
cd family-counseling-ui

# ایجاد پوشه public و زیرپوشه‌های آن
mkdir -p public/assets/images

# ایجاد پوشه app و زیرپوشه‌های آن
mkdir -p app/auth/login
mkdir -p app/auth/register
mkdir -p app/dashboard/consultant/availabilities
mkdir -p app/dashboard/consultant/sessions
mkdir -p app/dashboard/consultant/reviews
mkdir -p app/dashboard/client/consultants/\[id\]
mkdir -p app/dashboard/client/sessions
mkdir -p app/dashboard/admin/users
mkdir -p app/dashboard/admin/consultants
mkdir -p app/dashboard/admin/verify
mkdir -p app/dashboard/admin/sessions
mkdir -p app/profile

# ایجاد پوشه components و زیرپوشه‌های آن
mkdir -p components/common
mkdir -p components/auth
mkdir -p components/dashboard
mkdir -p components/consultants
mkdir -p components/clients
mkdir -p components/sessions
mkdir -p components/reviews
mkdir -p components/admin

# ایجاد سایر پوشه‌های اصلی
mkdir -p lib
mkdir -p hooks
mkdir -p mocks

# ایجاد فایل‌های کلیدی در ریشه پروژه
touch .env.local .gitignore package.json next.config.js tailwind.config.js README.md
touch public/favicon.ico

# ایجاد فایل‌های app
touch app/page.jsx app/layout.jsx app/globals.css app/not-found.jsx
touch app/auth/login/page.jsx app/auth/register/page.jsx
touch app/dashboard/page.jsx app/dashboard/layout.jsx
touch app/dashboard/consultant/page.jsx
touch app/dashboard/consultant/availabilities/page.jsx
touch app/dashboard/consultant/sessions/page.jsx
touch app/dashboard/consultant/reviews/page.jsx
touch app/dashboard/client/page.jsx
touch app/dashboard/client/consultants/page.jsx
touch app/dashboard/client/consultants/\[id\]/page.jsx
touch app/dashboard/client/sessions/page.jsx
touch app/dashboard/admin/page.jsx
touch app/dashboard/admin/users/page.jsx
touch app/dashboard/admin/consultants/page.jsx
touch app/dashboard/admin/verify/page.jsx
touch app/dashboard/admin/sessions/page.jsx
touch app/profile/page.jsx

# ایجاد فایل‌های components/common
touch components/common/Header.jsx
touch components/common/Footer.jsx
touch components/common/Sidebar.jsx
touch components/common/Navigation.jsx
touch components/common/LoadingSpinner.jsx

# ایجاد فایل‌های components/auth
touch components/auth/LoginForm.jsx
touch components/auth/RegisterForm.jsx

# ایجاد فایل‌های components/dashboard
touch components/dashboard/DashboardStats.jsx
touch components/dashboard/ActivityFeed.jsx

# ایجاد فایل‌های components/consultants
touch components/consultants/ConsultantCard.jsx
touch components/consultants/ConsultantFilters.jsx
touch components/consultants/AvailabilityCalendar.jsx
touch components/consultants/SpecialtiesList.jsx

# ایجاد فایل‌های components/clients
touch components/clients/ClientProfile.jsx
touch components/clients/BookingForm.jsx

# ایجاد فایل‌های components/sessions
touch components/sessions/SessionCard.jsx
touch components/sessions/SessionsList.jsx
touch components/sessions/SessionStatusBadge.jsx

# ایجاد فایل‌های components/reviews
touch components/reviews/ReviewForm.jsx
touch components/reviews/ReviewsList.jsx
touch components/reviews/StarRating.jsx

# ایجاد فایل‌های components/admin
touch components/admin/AdminStats.jsx
touch components/admin/UsersList.jsx
touch components/admin/ConsultantApproval.jsx
touch components/admin/SessionsTable.jsx

# ایجاد فایل‌های lib
touch lib/constants.js
touch lib/utils.js
touch lib/theme.js

# ایجاد فایل‌های hooks
touch hooks/useMediaQuery.js
touch hooks/useLocalStorage.js

# ایجاد فایل‌های mocks
touch mocks/consultants.js
touch mocks/sessions.js
touch mocks/reviews.js
touch mocks/users.js

echo "ساختار پروژه با موفقیت ایجاد شد!"
