بعد از مطالعه کدها و README پروژه، متوجه شدم که شما به یک رابط کاربری استاتیک برای پلتفرم مشاوره خانواده نیاز دارید که با Tailwind CSS طراحی شده باشد. براساس API موجود، یک ساختار فولدر پیشنهاد می‌کنم که برای یک UI استاتیک مناسب باشد:

```
family-counseling-ui/
├── assets/
│   ├── images/
│   │   ├── logo.svg
│   │   ├── icons/
│   │   └── placeholders/
│   ├── css/
│   │   └── tailwind.css
│   └── js/
│       └── scripts.js
│
├── pages/
│   ├── index.html                    # صفحه اصلی
│   ├── auth/
│   │   ├── login.html                # ورود
│   │   └── register.html             # ثبت نام
│   │
│   ├── client/
│   │   ├── dashboard.html            # داشبورد کاربر
│   │   ├── find-consultants.html     # جستجوی مشاوران
│   │   ├── consultant-profile.html   # مشاهده پروفایل مشاور
│   │   ├── book-session.html         # رزرو جلسه
│   │   ├── my-sessions.html          # جلسات من
│   │   └── reviews.html              # نظرات من
│   │
│   ├── consultant/
│   │   ├── dashboard.html            # داشبورد مشاور
│   │   ├── profile.html              # پروفایل مشاور
│   │   ├── availability.html         # مدیریت زمان‌های در دسترس
│   │   ├── sessions.html             # مدیریت جلسات
│   │   └── reviews.html              # نظرات دریافتی
│   │
│   ├── messaging/
│   │   └── chat.html                 # پیام‌رسانی
│   │
│   ├── admin/
│   │   ├── dashboard.html            # داشبورد ادمین
│   │   ├── users.html                # مدیریت کاربران
│   │   ├── consultants.html          # مدیریت مشاوران
│   │   ├── verify-consultants.html   # تأیید مشاوران
│   │   └── sessions.html             # مدیریت جلسات
│   │
│   └── user/
│       ├── profile.html              # مشاهده/ویرایش پروفایل
│       └── settings.html             # تنظیمات کاربر
│
├── components/
│   ├── layout/
│   │   ├── header.html               # هدر
│   │   ├── footer.html               # فوتر
│   │   ├── sidebar-client.html       # منوی کناری مخصوص کاربر
│   │   ├── sidebar-consultant.html   # منوی کناری مخصوص مشاور
│   │   └── sidebar-admin.html        # منوی کناری مخصوص ادمین
│   │
│   ├── cards/
│   │   ├── consultant-card.html      # کارت نمایش مشاور
│   │   ├── session-card.html         # کارت نمایش جلسه
│   │   └── review-card.html          # کارت نمایش نظر
│   │
│   ├── forms/
│   │   ├── login-form.html           # فرم ورود
│   │   ├── register-form.html        # فرم ثبت نام
│   │   ├── profile-form.html         # فرم پروفایل
│   │   ├── availability-form.html    # فرم زمان‌های در دسترس
│   │   ├── session-form.html         # فرم رزرو جلسه
│   │   └── review-form.html          # فرم ثبت نظر
│   │
│   └── ui/
│       ├── button.html               # دکمه
│       ├── input.html                # فیلد ورودی
│       ├── select.html               # منوی کشویی
│       ├── badge.html                # نشان‌ها
│       ├── alert.html                # هشدارها
│       ├── modal.html                # پنجره مودال
│       ├── pagination.html           # صفحه‌بندی
│       └── table.html                # جدول
│
└── templates/
    ├── client-template.html          # قالب پایه کاربر
    ├── consultant-template.html      # قالب پایه مشاور
    └── admin-template.html           # قالب پایه ادمین
```

این ساختار فولدر به صورت منطقی صفحات و اجزای UI را سازماندهی می‌کند:

1. **assets/**: فایل‌های استاتیک مانند تصاویر، CSS و JavaScript
2. **pages/**: همه صفحات HTML سازماندهی شده بر اساس نقش کاربر و قابلیت‌ها
3. **components/**: اجزای قابل استفاده مجدد که در صفحات مختلف استفاده می‌شوند
4. **templates/**: قالب‌های پایه که ساختار اصلی هر نوع صفحه را تعریف می‌کنند

با این ساختار، می‌توانیم به صورت تدریجی UI را با استفاده از Tailwind CSS بسازیم و از اجزای مشترک بین صفحات مختلف استفاده مجدد کنیم.