// Main JavaScript file for Family Counseling Platform

// Document Ready Function
document.addEventListener("DOMContentLoaded", function () {
  // Initialize mobile menu toggle
  initMobileMenu();

  // Initialize dropdowns
  initDropdowns();

  // Initialize modals
  initModals();

  // Initialize tabs
  initTabs();
});

// Mobile Menu Toggle
function initMobileMenu() {
  const menuToggle = document.getElementById("mobile-menu-toggle");
  const mobileMenu = document.getElementById("mobile-menu");

  if (!menuToggle || !mobileMenu) return;

  menuToggle.addEventListener("click", function () {
    mobileMenu.classList.toggle("hidden");
  });
}

// Dropdown Initialization
function initDropdowns() {
  const dropdownToggleButtons = document.querySelectorAll(
    "[data-dropdown-toggle]"
  );

  dropdownToggleButtons.forEach((button) => {
    const targetId = button.getAttribute("data-dropdown-toggle");
    const dropdown = document.getElementById(targetId);

    if (!dropdown) return;

    button.addEventListener("click", function (e) {
      e.stopPropagation();
      dropdown.classList.toggle("hidden");
    });
  });

  // Close dropdowns when clicking outside
  document.addEventListener("click", function () {
    const openDropdowns = document.querySelectorAll(".dropdown:not(.hidden)");
    openDropdowns.forEach((dropdown) => {
      dropdown.classList.add("hidden");
    });
  });
}

// Modal Initialization
function initModals() {
  const modalToggleButtons = document.querySelectorAll("[data-modal-toggle]");

  modalToggleButtons.forEach((button) => {
    const targetId = button.getAttribute("data-modal-toggle");
    const modal = document.getElementById(targetId);

    if (!modal) return;

    button.addEventListener("click", function () {
      modal.classList.toggle("hidden");
    });

    // Close button inside modal
    const closeButtons = modal.querySelectorAll("[data-modal-close]");
    closeButtons.forEach((closeBtn) => {
      closeBtn.addEventListener("click", function () {
        modal.classList.add("hidden");
      });
    });

    // Close modal when clicking on overlay
    modal.addEventListener("click", function (e) {
      if (e.target === modal) {
        modal.classList.add("hidden");
      }
    });
  });
}

// Tabs Initialization
function initTabs() {
  const tabGroups = document.querySelectorAll("[data-tabs]");

  tabGroups.forEach((tabGroup) => {
    const tabButtons = tabGroup.querySelectorAll("[data-tab-target]");

    tabButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const targetId = button.getAttribute("data-tab-target");
        const tabContent = document.getElementById(targetId);

        if (!tabContent) return;

        // Hide all tab contents in this group
        const allTabContents = tabGroup.querySelectorAll("[data-tab-content]");
        allTabContents.forEach((content) => {
          content.classList.add("hidden");
        });

        // Show the target tab content
        tabContent.classList.remove("hidden");

        // Set active state for tab buttons
        tabButtons.forEach((btn) => {
          btn.classList.remove("bg-primary", "text-white");
          btn.classList.add("bg-white", "text-gray-700");
        });

        button.classList.remove("bg-white", "text-gray-700");
        button.classList.add("bg-primary", "text-white");
      });
    });

    // Activate first tab by default
    if (tabButtons.length > 0) {
      tabButtons[0].click();
    }
  });
}

// Form validation helper
function validateForm(form) {
  const inputs = form.querySelectorAll(
    "input[required], select[required], textarea[required]"
  );
  let isValid = true;

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      input.classList.add("border-red-500");
      const errorMessage =
        input.getAttribute("data-error-message") || "این فیلد الزامی است.";

      // Create or update error message
      let errorEl = input.nextElementSibling;
      if (!errorEl || !errorEl.classList.contains("error-message")) {
        errorEl = document.createElement("p");
        errorEl.classList.add(
          "error-message",
          "text-sm",
          "text-red-500",
          "mt-1"
        );
        input.parentNode.insertBefore(errorEl, input.nextSibling);
      }
      errorEl.textContent = errorMessage;

      isValid = false;
    } else {
      input.classList.remove("border-red-500");
      const errorEl = input.nextElementSibling;
      if (errorEl && errorEl.classList.contains("error-message")) {
        errorEl.remove();
      }
    }
  });

  return isValid;
}

// Toast notification function
function showToast(message, type = "success", duration = 3000) {
  const toast = document.createElement("div");
  toast.className = `fixed bottom-4 left-4 p-4 rounded-md shadow-lg text-white ${
    type === "success"
      ? "bg-green-500"
      : type === "error"
      ? "bg-red-500"
      : type === "warning"
      ? "bg-yellow-500"
      : "bg-blue-500"
  } transition-opacity duration-300 opacity-0`;
  toast.textContent = message;

  document.body.appendChild(toast);

  // Fade in
  setTimeout(() => {
    toast.classList.replace("opacity-0", "opacity-100");
  }, 10);

  // Fade out and remove
  setTimeout(() => {
    toast.classList.replace("opacity-100", "opacity-0");
    setTimeout(() => {
      document.body.removeChild(toast);
    }, 300);
  }, duration);
}
